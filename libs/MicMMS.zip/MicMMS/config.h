#ifndef CONFIG_H
#define CONFIG_H

// #### WIFI Config  #### //

// #### MQTT Config  #### //

// const char* mqtt_server = "192.168.1.111";
char* topic_pub_1 = "data";  // ball/insp/A001/data
char* topic_pub_2 = "status";
char* topic_pub_3 = "alarm";
char* topic_esp_health = "esp_health";
//  char* topic_sub_1 = "sub_1";

// #### Modbus Address Config  #### //
const uint16_t itr_modbus = 100;  // ms   0.1s
const uint16_t itr_fnc_1 = 1000;  // ms   1s
const uint16_t itr_fnc_2 = 1000;  // ms
const uint16_t itr_fnc_3 = 1000;  // ms
const uint16_t itr_esp = 20000;   // ms    20s

const uint8_t num_got_data = 130;
uint16_t got_data[num_got_data];
float init_heap;
int total_data, Add_convert = 65536;

String prv_status, status;
String prv_alarm, alarm_;
String Lot_ttl, Model_ttl;
uint16_t prv_time = 0;
uint16_t heap_cnt1, heap_cnt2, heap_cnt3;
uint16_t ct_fn1, ct_fn2, ct_fn3, ct_read, ct_read1;
uint16_t ct_read_cnt, ct_fn1_cnt, ct_fn2_cnt, ct_fn3_cnt;
uint16_t ct_read_ = 220;
uint16_t ct_fn1_ = 3500;
uint16_t ct_fn2_ = 1800;
uint16_t ct_fn3_ = 2300;

String def_tb[][5] = {
  // name||address||type||value||prv_value
  // type for separate detail of data
  { "1", "1", "1", "", "" },      //mc_run
  { "2", "2", "1", "", "" },      //mc_stop
  { "3", "3", "1", "", "" },      //mc_alarm
  { "4", "4", "1", "", "" },      //mc_waitpart
  { "5", "5", "1", "", "" },      //mc_fullWork
  { "H1 R.WORN STONE", "21", "2", "", "" },         //Alarm status
  { "H1 F.WORN STONE", "22", "2", "", "" },
  { "H1 CLAMP ERROR", "23", "2", "", "" },
  { "H1 NO WORK", "24", "2", "", "" },
  { "H1 TL.ENGAUGE ERROR", "25", "2", "", "" },
  { "H1 LOCATOR ERROR", "26", "2", "", "" },
  { "H1 ESCAPE ERROR", "27", "2", "", "" },
  { "H1 STONE PRESSURE DOWN", "28", "2", "", "" },
  { "H1 CHUTE EMPTY", "29", "2", "", "" },
  { "H1 FULL WORK", "30", "2", "", "" },
  { "H1 CY.TIME OVER", "31", "2", "", "" },
  { "H1 UNLOAD CHUTE ERR.", "32", "2", "", "" },
  { "H1 W.MOTOR WARM UP", "33", "2", "", "" },
  { "H2 R.WORN STONE", "34", "2", "", "" },
  { "H2 F.WORN STONE", "35", "2", "", "" },
  { "H2 CLAMP ERROR", "36", "2", "", "" },
  { "H2 NO WORK", "37", "2", "", "" },
  { "H2 TL.ENGAUGE ERROR", "38", "2", "", "" },
  { "H2 LOCATOR ERROR", "39", "2", "", "" },
  { "H2 ESCAPE ERROR", "40", "2", "", "" },
  { "H2 STONE PRESSURE DOWN", "41", "2", "", "" },
  { "H2 CHUTE EMPTY", "42", "2", "", "" },
  { "H2 FULL WORK", "43", "2", "", "" },
  { "H2 CY.TIME OVER", "44", "2", "", "" },
  { "H2 UNLOAD CHUTE ERR.", "45", "2", "", "" },
  { "H2 W.MOTOR WARM UP", "46", "2", "", "" },
  { "NO USE", "47", "2", "", "" },
  { "NO USE", "48", "2", "", "" },
  { "NO USE", "49", "2", "", "" },
  { "DAY START", "50", "2", "", "" },
  { "yyyy", "71", "0", "", "" },               //Date time
  { "mm", "72", "0", "", "" },
  { "dd", "73", "0", "", "" },
  { "hh", "74", "0", "", "" },
  { "min", "75", "0", "", "" },
  { "sec", "76", "0", "", "" },
  //{ "mc_status", "92", "3", "", "" },
  { "each1", "99", "3", "", "" },
  { "each2", "100", "3", "", "" },
  { "idh1", "101", "3", "", "" },
  { "idh2", "102", "3", "", "" },
  { "utl_h1", "103", "3", "", "" },
  { "utl_h2", "104", "3", "", "" },
  { "prod_h1", "105", "4", "", "" },
  { "prod_h11", "106", "4", "", "" },
  { "prod_h2", "107", "4", "", "" },
  { "prod_h22", "108", "4", "", "" },
  { "prod_total", "109", "4", "", "" },
  { "prod_total1", "110", "4", "", "" },
  { "Lot1", "111", "5", "", "" },             //Lot number
  { "Lot2", "112", "5", "", "" },
  { "Lot3", "113", "5", "", "" },
  { "Lot4", "114", "5", "", "" },
  { "Lot5", "115", "5", "", "" },
  { "Model1", "116", "6", "", "" },         //Model number
  { "Model2", "117", "6", "", "" },
  { "Model3", "118", "6", "", "" },
  { "Model4", "119", "6", "", "" },
  { "Model5", "120", "6", "", "" },
  { "Model6", "121", "6", "", "" },
  { "Model7", "122", "6", "", "" },
  { "Model8", "123", "6", "", "" },
  { "Model9", "124", "6", "", "" },
  { "Model10", "125", "6", "", "" },

};

#endif