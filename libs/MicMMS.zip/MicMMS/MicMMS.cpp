#include "HardwareSerial.h"
#include "esp_system.h"
#include "MicMMS.h"
#include "config.h"

MicMMS::MicMMS(const char* ssid, const char* password, const char* mqtt_server, int mqtt_port, const char* mc_no, int slaveId, HardwareSerial& serialPort, const char* ip_address, const char* gateway_address, const char* subnet_mask)
  : wifiClient(), mqttClient(wifiClient), ssid(ssid), password(password), mqtt_server(mqtt_server), mqtt_port(mqtt_port), mc_no(mc_no), slaveId(slaveId), serialPort(serialPort), modbus(slaveId, serialPort, 0) {
  ip.fromString(ip_address);
  gateway.fromString(gateway_address);
  subnet.fromString(subnet_mask);
}

void MicMMS::init() {
  std::vector<std::vector<String>> def_tb;
  pinMode(1, OUTPUT);
  pinMode(2, OUTPUT);

  Serial.begin(115200);
  Serial1.begin(115200);
  WiFi.config(ip, gateway, subnet);
  WiFi.begin(ssid, password);
  while (WiFi.status() != WL_CONNECTED) {
    delay(1000);
    Serial.println("Connecting to WiFi...");
  }
  Serial.println("Connected to WiFi");
  Serial.println(WiFi.localIP());
  mqttClient.setServer(mqtt_server, mqtt_port);

  digitalWrite(2, HIGH);
  init_heap = esp_get_free_heap_size();
  modbus.start();
}

void MicMMS::reconnect() {
  while (!mqttClient.connected()) {
    Serial.println("Attempting MQTT connection...");
    if (mqttClient.connect("ESP32Client")) {
      Serial.println("Connected to MQTT Broker");
    } else {
      Serial.print("Failed with state ");
      Serial.print(mqttClient.state());
      delay(2000);
    }
  }
}

void MicMMS::publishMessage(char* topic, const char* message) {
  if (!mqttClient.connected()) {
    reconnect();
  }
  mqttClient.publish(topic, message);
}

void MicMMS::run() {
  if (!mqttClient.connected()) {
    reconnect();
    digitalWrite(2, HIGH);
  }
  modbus.poll(got_data, num_got_data);
}

void MicMMS::start() {
  xTaskCreatePinnedToCore(modbus_Task, "Task0", 10000, this, 5, NULL, 0);
  xTaskCreatePinnedToCore(func1_Task, "Task1", 10000, this, 4, NULL, 0);
  xTaskCreatePinnedToCore(func2_Task, "Task2", 10000, this, 3, NULL, 0);
  xTaskCreatePinnedToCore(func3_Task, "Task3", 10000, this, 2, NULL, 0);
  xTaskCreatePinnedToCore(esp_Task, "Task4", 10000, this, 1, NULL, 0);
}

void MicMMS::modbus_Task(void* pvParam) {
  MicMMS* instance = (MicMMS*)pvParam;
  while (1) {
    //int count_data = 0;
    //record raw data to table
    unsigned long long int start = micros();
    for (int i = 0; i < sizeof(def_tb) / sizeof(def_tb[0]); i++) {
      def_tb[i][3] = got_data[(def_tb[i][1].toInt()) - 1];
    }
    // clean data yy-->yyyy
    for (int i = 0; i < sizeof(def_tb) / sizeof(def_tb[0]); i++) {
      if (def_tb[i][0] == "yyyy" and def_tb[i][3].length() == 2) {  //select only yy
        def_tb[i][3] = "20" + def_tb[i][3];
      }
    }
    ct_read = micros() - start;
    //interval work loop 250-260 microsec
    Serial.println(ct_read);
    vTaskDelay(pdMS_TO_TICKS(itr_modbus));  //loop get value every 100 sec
  }
}

void MicMMS::func1_Task(void* pvParam) {
  MicMMS* instance = (MicMMS*)pvParam;
  MicMMS* mcNo = (MicMMS*)(pvParam);

  char topic_pub[30];
  strcpy(topic_pub, topic_pub_1);
  strcat(topic_pub, mcNo->mc_no);

  while (1) {
    unsigned long long int start = micros();
    bool change_1 = false;

    StaticJsonDocument<300> json_1;  // size = 30*topic [avg]
    // check data change
    for (int i = 0; i < sizeof(def_tb) / sizeof(def_tb[0]); i++) {
      if (def_tb[i][2] == "3" || def_tb[i][2] == "4" || def_tb[i][2] == "5" || def_tb[i][2] == "6") {
        if (def_tb[i][3] != def_tb[i][4]) {
          change_1 = true;
          break;
        }
      }
    }
    if (change_1 == true) {  // data change !!!

      /*----------- RSSI value -----------*/
      json_1["rssi"] = (float)WiFi.RSSI();

      /*----------- Production data -----------*/
      for (int j = 0; j < (sizeof(def_tb) / sizeof(def_tb[0])); j++) {
        if (def_tb[j][2] == "3") {
          json_1[String(def_tb[j][0])] = (def_tb[j][3]).toInt();
        }
      }
      for (int k = 0; k < (sizeof(def_tb) / sizeof(def_tb[0])); k++) {
        if (def_tb[k][2] == "4") {
          total_data = (def_tb[k][3]).toFloat() + ((def_tb[k + 1][3]).toFloat() * Add_convert);
          json_1[String(def_tb[k][0])] = (total_data);
          k++;
        }
      }

      /*----------------- Lot Number -----------------*/
      for (int m = 0; m < (sizeof(def_tb) / sizeof(def_tb[0])); m++) {
        if (def_tb[m][2] == "5") {
          if (def_tb[m][3].toInt() != 0) {
            String hex_ = String((def_tb[m][3]).toInt(), HEX);  //convert data to HEX and define -> String
            String fristPart = hex_.substring(2, 4);            // Split data
            String secondPart = hex_.substring(0, 2);
            long ascii_1 = strtol(fristPart.c_str(), NULL, 16);  //convert data HEX to DEC
            long ascii_2 = strtol(secondPart.c_str(), NULL, 16);
            //Lot_num = String(ascii_1) + String(ascii_2);
            //json_1[String(def_tb[m][0])] = Lot_num.toInt();  //Tx DEC to MQTT type json file
            if (ascii_1 == 32) {
              ascii_1 = 0;
            }
            if (ascii_2 == 32) {
              ascii_2 = 0;
            }
            String Lot_num = String(char(ascii_1)) + String(char(ascii_2));
            Lot_ttl += Lot_num;
          }
        }
      }
      json_1["lot"] = Lot_ttl;

      /*----------------- Model Number -----------------*/
      for (int n = 0; n < (sizeof(def_tb) / sizeof(def_tb[0])); n++) {
        if (def_tb[n][2] == "6") {
          if (def_tb[n][3].toInt() != 0) {
            String hex_1 = String((def_tb[n][3]).toInt(), HEX);
            String fristPart_mdl = hex_1.substring(2, 4);
            String secondPart_mdl = hex_1.substring(0, 2);
            long ascii_mdl1 = strtol(fristPart_mdl.c_str(), NULL, 16);
            long ascii_mdl2 = strtol(secondPart_mdl.c_str(), NULL, 16);
            if (ascii_mdl1 == 32) {
              ascii_mdl1 = 0;
            }
            if (ascii_mdl2 == 32) {
              ascii_mdl2 = 0;
            }
            String model_num = String(char(ascii_mdl1)) + String(char(ascii_mdl2));
            Model_ttl += model_num;
          }
        }
      }
      json_1["model"] = Model_ttl;

      /*----------- Publish data -----------*/
      String json_topic1;
      serializeJson(json_1, json_topic1);
      // instance->publishMessage(mcNo->mc_no, json_topic1.c_str());
      instance->publishMessage(topic_pub, json_topic1.c_str());
      for (int p = 0; p < sizeof(def_tb) / sizeof(def_tb[0]); p++) {
        if (def_tb[p][2] == "3" || def_tb[p][2] == "4" || def_tb[p][2] == "5" || def_tb[p][2] == "6") {
          def_tb[p][4] = def_tb[p][3];
          if (def_tb[p][2] == "5") {
            if (def_tb[p][3].toInt() != 0) {
              Lot_ttl = '\0';
            }
          }
          if (def_tb[p][2] == "6") {
            if (def_tb[p][3].toInt() != 0) {
              Model_ttl = '\0';
            }
          }
        }
      }
      ct_fn1 = micros() - start;
      digitalWrite(1, HIGH);
      delay(100);
      digitalWrite(1, LOW);
    }
    //ct_read1 = micros() - start;
    Serial.print("-------------------------");
    Serial.print(ct_fn1);
    vTaskDelay(pdMS_TO_TICKS(itr_fnc_1));  //check every 1 sec
  }
}

void MicMMS::func2_Task(void* pvParam) {
  MicMMS* instance = (MicMMS*)pvParam;
  MicMMS* mcNo = (MicMMS*)(pvParam);
  char topic_pub[30];
  strcpy(topic_pub, topic_pub_2);
  strcat(topic_pub, mcNo->mc_no);

  while (1) {
    unsigned long long int start = micros();
    bool data_check1 = false;
    uint8_t count_data1 = 0;
    for (int i = 0; i < sizeof(def_tb) / sizeof(def_tb[0]); i++) {
      if (def_tb[i][2] == "1") {    //type status
        if (def_tb[i][3] == "1") {  //value to register(number)
          count_data1++;            //count_data1 = 1
        }
      }
    }

    if (count_data1 == 1) {  // condition to protection from many value
      data_check1 = true;
    } else {
      data_check1 = false;
      count_data1 = 0;
    }

    StaticJsonDocument<300> json_2;
    if (data_check1 == true) {  // data change and only one!!
      /*----------- Date time -----------*/
      for (int j = 0; j < sizeof(def_tb) / sizeof(def_tb[0]); j++) {
        if (def_tb[j][2] == "0") {                              // 0--> d_time
          json_2[String(def_tb[j][0])] = def_tb[j][3].toInt();  //yyyy-MM-dd HH:mm:ss
        }
      }
      for (int i = 0; i < sizeof(def_tb) / sizeof(def_tb[0]); i++) {
        if (def_tb[i][2] == "1") {
          if (def_tb[i][3] == "1") {
            status = def_tb[i][0];
            json_2["status"] = status;
          }
        }
      }
    }
    /*----------- Publish data -----------*/
    if (status != prv_status) {
      String json_topic2;
      serializeJson(json_2, json_topic2);
      instance->publishMessage(topic_pub, json_topic2.c_str());

      prv_status = status;
      ct_fn2 = micros() - start;
      digitalWrite(1, HIGH);
      delay(100);
      digitalWrite(1, LOW);
    }
    vTaskDelay(pdMS_TO_TICKS(itr_fnc_2));
  }
}

void MicMMS::func3_Task(void* pvParam) {
  MicMMS* instance = (MicMMS*)pvParam;
  MicMMS* mcNo = (MicMMS*)(pvParam);
  char topic_pub[30];
  strcpy(topic_pub, topic_pub_3);
  strcat(topic_pub, mcNo->mc_no);
  while (1) {
    unsigned long long int start = micros();
    bool Ready_1 = false;
    StaticJsonDocument<300> json_3;

    /*-------- Date time --------*/
    for (int i = 0; i < sizeof(def_tb) / sizeof(def_tb[0]); i++) {
      if (def_tb[i][2] == "0") {                              // 0--> d_time
        json_3[String(def_tb[i][0])] = def_tb[i][3].toInt();  //yyyy-MM-dd HH:mm:ss
      }
    }

    /*------- alarm list and Publish data -------*/
    for (int j = 0; j < sizeof(def_tb) / sizeof(def_tb[0]); j++) {
      if (def_tb[j][2] == "2") {
        if (def_tb[j][3] == "1" && def_tb[j][4] == "") {
          alarm_ = def_tb[j][0];
          json_3["status"] = alarm_;
          String json_topic3;
          serializeJson(json_3, json_topic3);
          instance->publishMessage(topic_pub, json_topic3.c_str());
          def_tb[j][4] = def_tb[j][3];
        }
        if (def_tb[j][3] == "1" && def_tb[j][4] == "0") {
          alarm_ = def_tb[j][0];
          json_3["status"] = alarm_;
          String json_topic3;
          serializeJson(json_3, json_topic3);
          instance->publishMessage(topic_pub, json_topic3.c_str());
          def_tb[j][4] = def_tb[j][3];
        }
        if (def_tb[j][3] == "0" && def_tb[j][4] == "1") {
          alarm_ = def_tb[j][0];
          json_3["status"] = alarm_ + "_";
          String json_topic3;
          serializeJson(json_3, json_topic3);
          instance->publishMessage(topic_pub, json_topic3.c_str());
          def_tb[j][4] = def_tb[j][3];
        }
        ct_fn3 = micros() - start;
        digitalWrite(1, HIGH);
        delay(100);
        digitalWrite(1, LOW);
      }
    }
    vTaskDelay(pdMS_TO_TICKS(itr_fnc_3));
  }
}

void MicMMS::esp_Task(void* pvParam) {  //ESP status
  MicMMS* instance = (MicMMS*)pvParam;
  MicMMS* mcNo = (MicMMS*)(pvParam);

  char topic_pub[30];
  strcpy(topic_pub, topic_esp_health);
  strcat(topic_pub, mcNo->mc_no);
  //strcpy(topic_pub, mcNo->mc_no);
  //strcat(topic_pub, topic_esp_health);
  while (1) {
    StaticJsonDocument<200> json_4;
    String json_topic4;
    float use_heap = (1 - (esp_get_free_heap_size() / init_heap)) * 100;
    // check heap
    if (use_heap >= 5.0 && use_heap <= 10.0) {
      heap_cnt1++;
    } else if (use_heap > 10.0 && use_heap <= 20.0) {
      heap_cnt2++;
    } else if (use_heap > 20.0) {
      heap_cnt3++;
    }
    // check cpu
    // Serial.println(ct_read);
    float read_over = ((ct_read / ct_read_) - 1) * 100;
    // Serial.println(read_over);
    if (read_over > 80) {
      ct_read_cnt++;
    }
    float fnc1_over = ((ct_fn1 / ct_fn1_) - 1) * 100;
    if (fnc1_over > 80) {
      ct_fn1_cnt++;
    }
    float fnc2_over = ((ct_fn2 / ct_fn2_) - 1) * 100;
    if (fnc2_over > 80) {
      ct_fn2_cnt++;
    }
    float fnc3_over = ((ct_fn3 / ct_fn3_) - 1) * 100;
    if (fnc3_over > 80) {
      ct_fn3_cnt++;
    }

    if (millis() - prv_time >= 12 * 60 * 60 * 1000) {  // 12hr
      json_4["mem_use"] = use_heap;
      json_4["mem_cnt1"] = heap_cnt1;
      json_4["mem_cnt2"] = heap_cnt2;
      json_4["mem_cnt3"] = heap_cnt3;
      json_4["cpu_fn0"] = ct_read_cnt;
      json_4["cpu_fn1"] = ct_fn1_cnt;
      json_4["cpu_fn2"] = ct_fn2_cnt;
      json_4["cpu_fn3"] = ct_fn3_cnt;

      serializeJson(json_4, json_topic4);
      instance->publishMessage(topic_pub, json_topic4.c_str());
      prv_time = millis();
      heap_cnt1 = 0;
      heap_cnt2 = 0;
      heap_cnt3 = 0;
      ct_read_cnt = 0;
      ct_fn1_cnt = 0;
      ct_fn2_cnt = 0;
      ct_fn3_cnt = 0;
    }
    vTaskDelay(pdMS_TO_TICKS(itr_esp));
  }
}